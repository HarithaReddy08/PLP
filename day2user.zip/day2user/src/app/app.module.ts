import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserListingComponent } from './component/user-listing/user-listing.component';
import { CreateNewUserComponent } from './component/create-new-user/create-new-user.component';
import { EditUserComponent } from './component/edit-user/edit-user.component';

import {UserService} from './service/user.service';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import {FormsModule} from '@angular/forms'

@NgModule({
  declarations: [
    AppComponent,
    UserListingComponent,
    CreateNewUserComponent,
    EditUserComponent,

    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    
    FormsModule
  ],
  providers: [UserService],
  bootstrap: [AppComponent]
})
export class AppModule { }
