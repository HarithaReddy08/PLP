import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserListingComponent } from './component/user-listing/user-listing.component';
import { CreateNewUserComponent } from './component/create-new-user/create-new-user.component';
import { EditUserComponent } from './component/edit-user/edit-user.component';


const routes: Routes = [
   {path:'', redirectTo:'list',pathMatch:'full'},
  {path:'list',component:UserListingComponent},
  { path: 'create', component: CreateNewUserComponent },
  {path : 'list/edit/:id',component:EditUserComponent},
  {path:'save',redirectTo:'list',pathMatch:'full'}



];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
