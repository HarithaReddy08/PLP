import { Injectable } from '@angular/core';
import { User } from '../user';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {
user:User;
private id;
userUrl:string = 'http://localhost:8087';

  constructor(private http:HttpClient) { }
  public createNewUser(user :User):Observable<User>
    {
      return this.http.post<User>(this.userUrl,user);
    }
  
  public userListing()
  {
    return this.http.get<User[]>(this.userUrl)
  }
  deleteUser(user :User)
  {
    return this.http.delete<User[]>(this.userUrl+"/"+user.id);
  }
  editUser(user :User)
  {
    return this.http.put<User>(this.userUrl+"/"+user.id,user);
  }
  getUser(id:number)
  {
    return this.http.get<User>(this.userUrl+"/"+id);
  }
  saveUser(user:User)
  {
  
  return this.http.post(this.userUrl,user);
    
  }
}



  
