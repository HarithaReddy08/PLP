import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/user';
import { UserService } from 'src/app/service/user.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-create-new-user',
  templateUrl: './create-new-user.component.html',
  styleUrls: ['./create-new-user.component.css']
})
export class CreateNewUserComponent implements OnInit {
  userData:User={"index":0,"id":0,"email":'',"fullName":'',"password":''}
user:User;
  constructor(private userService:UserService,private router:Router) { }

  ngOnInit() {

  }
  createNewUser()
  {
    console.log(this.userData.fullName);
    this.userService.createNewUser(this.userData).subscribe((data)=>{this.router.navigate(['list']);});
  }

   

      
    
}