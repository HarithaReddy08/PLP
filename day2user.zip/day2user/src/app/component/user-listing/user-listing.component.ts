import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/user';
import { UserService } from 'src/app/service/user.service';

@Component({
  selector: 'app-user-listing',
  templateUrl: './user-listing.component.html',
  styleUrls: ['./user-listing.component.css']
})
export class UserListingComponent implements OnInit {
users:User[];
  constructor(private userService:UserService) { }

  ngOnInit() {
    this.userService.userListing().subscribe((data:User[])=>{this.users=data;
      console.log("all"+this.users)});
  }
  deleteUser(user:User){
    this.userService.deleteUser(user).subscribe((data)=>{this.users=this.users.filter(c=>c!==user)});


}
}