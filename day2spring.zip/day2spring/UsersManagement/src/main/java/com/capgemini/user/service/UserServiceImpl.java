package com.capgemini.user.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.user.bean.User;
import com.capgemini.user.dao.UserDao;
@Service
public class UserServiceImpl implements UserService{
@Autowired
private UserDao userdao;
	public void createNewUser(User userdtls) {
	userdao.save(userdtls);
		
	}

	public List<User> deleteUser(int id) {
		
			userdao.deleteById(id);

			return listUser();
	}

	public List<User> listUser() {
		
		return userdao.findAll();
	
	}

	@Override
	public List<User> Editlist(User userdtls) {
	 userdao.save(userdtls);
	 return listUser();
	}

	@Override
	public List<User> saveList(User userdtls) {

		userdao.save(userdtls);
        return listUser();
	}

}
