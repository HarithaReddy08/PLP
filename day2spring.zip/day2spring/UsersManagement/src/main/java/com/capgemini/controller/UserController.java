package com.capgemini.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.user.bean.User;
import com.capgemini.user.service.UserService;

@RestController
@CrossOrigin(origins="http://localhost:4200")
public class UserController {
@Autowired
private UserService userservice;
@PostMapping
public void createNewUser(@RequestBody User userdtls)
{
	userservice.createNewUser(userdtls);
}
@DeleteMapping("/delete/{id}")
public List<User> deleteUser(@PathVariable int id)
{
	return userservice.deleteUser(id);

}
@GetMapping("/list")
public List<User> listUser()
{
	return userservice.listUser();
	
}
@PutMapping("/edit")
public List<User> Editlist(@RequestBody User userdtls)
{
	return userservice.listUser();
}
@PostMapping("/list")
public List<User> addEmplyee(@RequestBody User userdtls){ 
	return userservice.saveList(userdtls);
	
}
}