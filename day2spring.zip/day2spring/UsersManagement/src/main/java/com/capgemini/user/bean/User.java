package com.capgemini.user.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
@Entity
@Table(name="UserEntry")
public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)	
private int id;
private String email;
private String fullName;
private String Password;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}

public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getFullName() {
	return fullName;
}
public void setFullName(String fullName) {
	this.fullName = fullName;
}
public String getPassword() {
	return Password;
}
public void setPassword(String password) {
	Password = password;
}


}
