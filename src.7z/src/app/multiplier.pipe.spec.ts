import { MultiplierPipe } from './multiplier.pipe';

describe('MultiplierPipe', () => {
  it('create an instance', () => {
    const pipe = new MultiplierPipe();
    expect(pipe).toBeTruthy();
  });
});
