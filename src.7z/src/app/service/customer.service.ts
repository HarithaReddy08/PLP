import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Customer } from '../bean/customer';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
url:string=" http://localhost:3000/customers";
filtereddata:Customer[];
  constructor(private http:HttpClient) { }
  addCustomer(customer:Customer)
  {
return this.http.post(this.url,customer);
  }
  getAllCustomers()
  {
    return this.http.get<Customer[]>(this.url);
  }
  deleteCustomer(customer:Customer)
  {
    return this.http.delete<Customer[]>(this.url+"/"+customer.id);
  }
  getCustomer(id:number)
  {
    return this.http.get<Customer>(this.url+"/"+id);
  }
  updateCustomer(customer:Customer)
  {
    return this.http.put<Customer>(this.url+"/"+customer.id,customer);
  }
  isLoggedIn()
  {
    var data=sessionStorage.getItem("loginstatus");
    if(data=="success")
    {
      return true;

    }else{
      return false;
    }
  }
  setSearchedata(searchedData:Customer[])
  {
this.filtereddata=searchedData;
  }
  getSearchedata()
  {
    return this.filtereddata;
  }
}
