import { ChangetextDirective } from './changetext.directive';

describe('ChangetextDirective', () => {
  it('should create an instance', () => {
    const directive = new ChangetextDirective();
    expect(directive).toBeTruthy();
  });
});
