package com.capgemini.user.service;


import java.util.List;

import com.capgemini.user.bean.User;

public interface UserService {
	public void createNewUser(User userdtls);
	public List<User> deleteUser(int id);
	public List<User> listUser();
	public List<User> Editlist(User userdtls);

}
