import { Injectable } from '@angular/core';
import { User } from '../user';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {
user:User;
private id;
private userUrl = 'http://localhost:9063/';

  constructor(private http:HttpClient) { }
  public createNewUser(user :User):Observable<User>
    {
      return this.http.post<User>(this.userUrl,user);
    }
  public userListing()
  {
    return this.http.get<User[]>(this.userUrl)
  }
  deleteUser(user :User)
  {
    return this.http.delete<User[]>(this.userUrl+"/"+user.id);
  }
  editUser(user :User)
  {
    return this.http.put<User>(this.userUrl+"/"+user.id,user);
  }
}



  
