import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserListingComponent } from './component/user-listing/user-listing.component';
import { CreateNewUserComponent } from './component/create-new-user/create-new-user.component';
import { EditUserComponent } from './component/edit-user/edit-user.component';
import { DeleteUserComponent } from './component/delete-user/delete-user.component';

const routes: Routes = [
   {path:'', redirectTo:'list',pathMatch:'full'},
  {path:'list',component:UserListingComponent},
  { path: 'create', component: CreateNewUserComponent },
  {path : 'edit',component:EditUserComponent},
  {path :'delete', component:DeleteUserComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
