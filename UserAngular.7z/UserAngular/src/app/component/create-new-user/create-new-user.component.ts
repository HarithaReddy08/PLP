import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/user';
import { UserService } from 'src/app/service/user.service';
@Component({
  selector: 'app-create-new-user',
  templateUrl: './create-new-user.component.html',
  styleUrls: ['./create-new-user.component.css']
})
export class CreateNewUserComponent implements OnInit {
user:User;
  constructor(private userService:UserService) { }

  ngOnInit() {
  }
createNewUser(email:string,fullName:string,password:string):void
{
if(email && fullName && password)
{
  this.user= new User(0,email,fullName,password);
  this.userService.createNewUser(this.user).subscribe();

      alert('Account Created Successfully!');
    
} else {
  alert('Please fill all details');
}
}
}

