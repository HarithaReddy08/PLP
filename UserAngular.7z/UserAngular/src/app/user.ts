export class User {
    
    id:number;
    email: string;
    fullName : string;
    password : string;
    
    constructor( id: number,email:string,fullName:string,password : string)
    {
      
        this.id=id;
        this.email=email;
        this.fullName=fullName;
        this.password=password;
    }
}


